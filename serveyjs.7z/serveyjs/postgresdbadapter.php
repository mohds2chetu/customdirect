<?php

class PostgresDBAdapter {
  private $dbh;

  public function __construct($config = null) {
    $this->dbh = new mysqli("localhost","root","","surveys");
    // Check connection
    if ($this->dbh-> connect_errno) {
      echo "Failed to connect to MySQL: " . $this->dbh-> connect_error;
      exit();
    }
  }

  public function getObjectFromStorage($storageId) {
    $sqlQuery = 'SELECT * FROM ' . $storageId;
    $data = array();
    $sql = $this->dbh->query($sqlQuery);
    while($result = $sql->fetch_assoc()) {
      $data[$result['id']] = $result;
    }
    return $data;
  }

  public function getSurveys() {
    // $surveys = array("MySurvey1" => '{
    //   "pages": [
    //   {
    //     "name": "page1",
    //     "elements": [
    //     {
    //       "type": "radiogroup",
    //       "choices": [
    //       "item1",
    //       "item2",
    //       "item3"
    //       ],
    //       "name": "question from survey1"
    //     }
    //     ]
    //   }
    //   ]
    // }',
    // "MySurvey2" => '{
    //   "pages": [
    //   {
    //     "name": "page1",
    //     "elements": [
    //     {
    //       "type": "checkbox",
    //       "choices": [
    //       "item1",
    //       "item2",
    //       "item3"
    //       ],
    //       "name": "question from survey2"
    //     }
    //     ]
    //   }
    //   ]
    // }' );
    $result = $this->getObjectFromStorage('surveys');
    // if(count($result) == 0) {
    //   $id1 = $this->addSurvey('MySurvey1');
    //   $this->storeSurvey($id1, $surveys['MySurvey1']);
    //   $id2 = $this->addSurvey('MySurvey2');
    //   $this->storeSurvey($id2, $surveys['MySurvey2']);
    //   $result = $surveys;
    // }
    return $result;
  }

  public function getSurvey($id) {    
    $storage = $this->getSurveys();
    $sql = $this->dbh->query('SELECT * FROM results WHERE postid=\'' . $id . '\' ');
    $result = $sql->fetch_assoc();
    $storage['partial'] = $result['pjson']; 
    $storage['survey'] = $storage[$id];      
    return json_encode($storage);

  }

  public function addSurvey($name) {
    try{
      $sqlQuery = $this->dbh->query('insert into surveys (name, json) values (\'' . $name . '\', \'{}\')');
      $sql = $this->dbh->query('SELECT * FROM surveys');
      $result = $sql->fetch_assoc();
      return $result['id'];
    }catch (PDOException $e){
      echo "Message :". $e;
    }
  }

  public function storeSurvey($id, $json) {
    $sqlQuery = $this->dbh->query('update surveys set json=\'' . $json . '\' where id=\'' . $id . '\'');
    $sql = $this->dbh->query("SELECT json FROM surveys where id =$id");
    $result = $sql->fetch_assoc();
    return $result;
  }

  public function deleteSurvey($id) {
    $this->dbh->query('DELETE FROM surveys WHERE id=\'' . $id . '\'');
  }

  public function changeName($id, $name) {
            //TODO
  }

  public function postResults($postId, $resultsJson) {
    $resultsJson =  str_replace("'","\'",$resultsJson);
    $find = $this->dbh->query("SELECT * FROM results WHERE postid =".$postId."");

    if($find->num_rows > 0){
     
      $sqlQuery = $this->dbh->query("update results SET postid =".$postId.", json = '".$resultsJson."', pjson = '".$resultsJson."', status = 'complete' where postid=$postId");  
    }else{
      
      $sqlQuery = $this->dbh->query("insert into results (postid, json, pjson, status) values ( ".$postId .",'" . $resultsJson ."','" . $resultsJson ."', 'complete')");
    }
   
    return $result['id'];
  }

  public function partialResults($postId, $resultsJson) {
    $resultsJson =  str_replace("'","\'",$resultsJson);
   
    $find = $this->dbh->query("SELECT * FROM results WHERE postid =".$postId." AND status ='in_progress'");  
    
    if($find->num_rows > 0){

      $sqlQuery = $this->dbh->query("update results SET postid =".$postId.", pjson = '".$resultsJson."', status = 'in_progress' where postid=$postId");      
    }else{
    
      $sqlQuery = $this->dbh->query("insert into results (postid, pjson, status) values ( ".$postId .",'" . $resultsJson ."', 'in_progress')");
      
    }
    
    //$sql = $this->dbh->query($sqlQuery);
    //$result = $sql->fetch(PDO::FETCH_ASSOC);
    return $result['id'];
  }


  public function getResultss($postId) {
    $data = array();
    $sql = $this->dbh->query('SELECT * FROM results WHERE postid=\'' . $postId . '\' ');
    while($result = $sql->fetch_assoc()) {
      array_push($data, $result['pjson']);
    }    
    return $data;
  }

  public function getResults($postId) {
    $data = array();
    $sql = $this->dbh->query('SELECT * FROM results WHERE postid=\'' . $postId . '\' ');
    while($result = $sql->fetch_assoc()) {
      array_push($data, $result['json']);
    }    
    return $data;
  }
}
?>