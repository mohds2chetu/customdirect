var result;
var xhr = new XMLHttpRequest();
        xhr.open("GET", 'http://test.chetu.local' + "/getSurvey?surveyId=" + 34);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function () {  
            var data = JSON.parse(xhr.response);          
            console.log(data.survey.json);
            result = data.survey.json;
			Survey
    .StylesManager
    .applyTheme("modern");

var json = result;
window.survey = new Survey.Model(result);

//var storageName = data.survey.name;
var storageName = "XYZ";

if (typeof window.localStorage !== 'undefined') {   
   var zz = window.localStorage.getItem(storageName);   
    if(zz === null || zz === undefined){
        alert("xxx");
          window.localStorage.setItem(storageName, data.partial);
          var zdz = window.localStorage.getItem(storageName);
          alert(zdz);
    } 
} else {
    alert("not found");
}


survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
    });


function saveSurveyData(survey,option) {    
    var data = survey.data;  
    data.pageNo = survey.currentPageNo;
    if(option === 'partial'){
        $.ajax({
            type: "POST",
            url: "partialSurvey",
            data: {resultsJson : JSON.stringify(data), postId: 34},
            cache: false,
            success: function(data){            
               $("#resultarea").text(data);
            }
          });
    }

    if(option === 'complete'){
        $.ajax({
            type: "POST",
            url: "post",
            data: {resultsJson : JSON.stringify(data), postId: 34},
            cache: false,
            success: function(data){            
               $("#resultarea").text(data);
            }
          });
    }
    
    window.localStorage.setItem(storageName, JSON.stringify(data));
}
survey
    .onPartialSend
    .add(function (survey) {
        saveSurveyData(survey,'partial'); 
    });
survey
    .onComplete
    .add(function (survey, options) {
        saveSurveyData(survey,'complete');
    });

survey.sendResultOnPageNext = true;
var prevData = window
    .localStorage
    .getItem(storageName) || null;
if (prevData) {
    var data = JSON.parse(prevData);
    survey.data = data;
    if (data.pageNo) {
        survey.currentPageNo = data.pageNo;
    }
}
$("#surveyElement").Survey({model: survey});
            //onLoad(xhr.status == 200, result, xhr.response);
        };
       xhr.send();


